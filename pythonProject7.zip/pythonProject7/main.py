import requests
import bs4


url = "https://2b.com.eg/ar/mobile-and-tablet/mobiles/apple.html"
page = requests.get(url)
#print(page.content)
soup = bs4.BeautifulSoup(page.content, "lxml")
#print(soup)
lists = soup.find_all('div' ,class_='product details product-item-details')
for list in lists:
    mobile_info = list.find('a', class_='product-item-link')
    mobile_price = list.find("span", class_='price')
    info = [mobile_info , mobile_price]
    print(info)

